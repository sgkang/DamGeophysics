**Research Projects & Lecture Content**
===================
More on the Quantopian Lecture Series at [quantopian.com/lectures](https://www.quantopian.com/lectures)

<a href="https://www.quantopian.com/lectures"><img src="http://i.imgur.com/KzPuAuJ.png"></a>

### License

[Creative Commons Attribution 4.0](https://creativecommons.org/licenses/by/4.0/legalcode)